.. _azureml:

AzureML module
**************************

AzureML module from Recommenders utilities.

AKS utils
===============================

.. automodule:: reco_utils.azureml.aks_utils
    :members:

AzureML utils
===============================

.. automodule:: reco_utils.azureml.azureml_utils
    :members:

