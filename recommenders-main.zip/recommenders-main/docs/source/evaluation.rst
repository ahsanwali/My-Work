.. _evaluation:

Evaluation module
**************************

Python evaluation
===============================

.. automodule:: reco_utils.evaluation.python_evaluation
    :members:

PySpark evaluation
===============================

.. automodule:: reco_utils.evaluation.spark_evaluation
    :members: