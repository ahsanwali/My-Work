# Recommendation System Scenarios

On this section there is listed a number of business scenarios that are common in Recommendation Systems.

The list of scenarios are:

* [Ads](ads)
* [Entertainment](entertainment)
* [Food and restaurants](food_and_restaurants)
* [News and document](news)
* [Retail](retail)
* [Travel](travel)




